---
# A Recent Blog Posts section created with the Pages widget.
# This section displays recent blog posts from `content/post/`.
# See https://wowchemy.com/docs/widget/pages/
widget: pages
headless: true
active: true
weight: 20
title: ''
subtitle: ''
content:
  offset: 0
  order: desc
  filters:
    folders:
      - post
    tag: ''
    category: ''
    publication_type: ''
    author: ''
    exclude_featured: false
  archive:
    enable: false
design:
  columns: '1'
  view: card
  flip_alt_rows: true
  background: {}
  spacing: {padding: [0, 0, 0, 0]}
---
